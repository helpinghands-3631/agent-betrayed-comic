import asyncio
import os
from fpdf import FPDF
from pydrive.auth import GoogleAuth
from pydrive.drive import GoogleDrive
from autogen_agentchat.agents import AssistantAgent
from autogen_ext.models.openai import OpenAIChatCompletionClient
from autogen_ext.tools.mcp import StdioServerParams, mcp_server_tools
from autogen_core import CancellationToken


def generate_comic_pdf(output_path="output/agent_betrayed_comic.pdf", panels_folder="output/panels"):
    pdf = FPDF()
    for filename in sorted(os.listdir(panels_folder)):
        if filename.endswith(".png") or filename.endswith(".jpg"):
            pdf.add_page()
            pdf.image(os.path.join(panels_folder, filename), x=0, y=0, w=210, h=297)  # A4 size
    os.makedirs(os.path.dirname(output_path), exist_ok=True)
    pdf.output(output_path)
    print(f"Comic PDF generated at {output_path}")


async def main() -> None:
    # Step 1: Setup MCP tool integration for file management
    server_params = StdioServerParams(
        command="npx.cmd", args=["-y", "@modelcontextprotocol/server-filesystem", "./comics"]
    )

    tools = await mcp_server_tools(server_params)

    # Step 2: Initialize the GPT-4o model with assistant agent
    agent = AssistantAgent(
        name="comic_creator",
        model_client=OpenAIChatCompletionClient(model="gpt-4o"),
        tools=tools,
        system_message="You are a professional comic book writer and illustrator AI. Generate a 20-page graphic novel including a front and back cover, with stylized narratives and bold illustrations in Chicano noir style."
    )

    # Step 3: Run the comic generation task
    await agent.run(
        task="Create a full 20-page comic book titled 'Agent: Betrayed' with bold storyline, noir visuals, front and back cover, and category assignment upon completion.",
        cancellation_token=CancellationToken()
    )

    # Step 4: Generate the PDF from comic panels
    generate_comic_pdf()

    # Step 5: GitHub sync (auto-commit and push)
    os.system("git add . && git commit -m 'Auto-generated comic update' && git push origin main")

    # Step 6: Google Drive upload
    gauth = GoogleAuth()
    gauth.LocalWebserverAuth()
    drive = GoogleDrive(gauth)

    file1 = drive.CreateFile({'title': 'agent_betrayed_comic.pdf'})
    file1.SetContentFile('output/agent_betrayed_comic.pdf')
    file1.Upload()
    print("Uploaded to Google Drive.")


if __name__ == "__main__":
    asyncio.run(main())
