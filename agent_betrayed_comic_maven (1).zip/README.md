# Comic Utils (Java)

This module contains AI agent-friendly utilities for managing comic metadata and publishing artifacts via Maven.