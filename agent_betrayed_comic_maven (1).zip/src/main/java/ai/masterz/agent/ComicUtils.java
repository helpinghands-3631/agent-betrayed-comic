package ai.masterz.agent;

public class ComicUtils {
    public static String getTitle() {
        return "Agent: Betrayed";
    }
}
